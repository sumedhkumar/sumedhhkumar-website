﻿import { ArrowRight, Code2, Cpu, Users } from "lucide-react";
import Button from "@/components/ui/Button";
import SectionIntro from "@/components/ui/SectionIntro";

const offerings = [
  {
    icon: Cpu,
    title: "AI Trading Software Agents",
    description:
      "Explore ready-to-purchase software products developed for structured trading workflows.",
    cta: "Explore Agents",
    target: "/ai-trading-agents",
  },
  {
    icon: Users,
    title: "Talk to Experts",
    description:
      "Book focused, one-to-one consultations with experienced professionals based on your requirements.",
    cta: "Explore Experts",
    target: "/experts",
  },
  {
    icon: Code2,
    title: "Custom Solutions",
    description:
      "Share your requirements for a website, software system, AI-enabled solution, workflow automation, or tailored digital product.",
    cta: "Submit Requirements",
    target: "/custom-solutions",
  },
];

export default function CoreOfferings() {
  return (
    <section className="section section-bg-primary">
      <div className="container">
        <SectionIntro
          heading="Explore Vyntegra"
          copy="Choose a ready-to-use AI trading software agent, book a one-to-one consultation with an expert, or share your requirements for a tailored digital solution."
        />

        <div className="offering-grid">
          {offerings.map((offering) => (
            <article
              key={offering.title}
              className="standard-card clickable-card"
              style={{ display: "flex", flexDirection: "column" }}
            >
              <offering.icon
                size={20}
                color="#B8914A"
                strokeWidth={1.75}
                style={{ marginBottom: 20 }}
              />
              <h3 className="card-title" style={{ marginBottom: 12 }}>
                {offering.title}
              </h3>
              <p className="body-standard" style={{ flexGrow: 1 }}>
                {offering.description}
              </p>
              <Button
                href={offering.target}
                variant="secondary"
                style={{ marginTop: 24 }}
              >
                {offering.cta} <ArrowRight size={16} strokeWidth={1.75} />
              </Button>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

